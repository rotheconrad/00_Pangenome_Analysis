#!~/.conda/envs/rothon/bin/python

## USAGE :: python scriptname.py cdhit_file.clstr
## Parses cdhit clusters into core, variable, and unique groups
## for core-pan genome analysis.
## builds rare-faction curve, unique genes per isolate barplot, and core-pan clustermap.

import sys, matplotlib
matplotlib.use('PDF')
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from collections import OrderedDict
from cdhit_summarize import ogs_summarize
from cdhit_Resolved_Plots import core_pan_clustermap


def resolve_clusters(clstr):
	
	BIG_D = {}
	binary_iD = {}
	og_iD = {}

	binary_D = {}
	og_D = {}

	cluster = None
	gene_list = []	

	cluster_rep_key = clstr + '.rep_key.tsv'
	rep_key_header = 'Cluster\tRepresentative_Sequence\tGenes_in_Cluster\tCluster_Gene_List\n'

	with open(clstr, 'r') as c, open(cluster_rep_key, 'w') as rep_key:
		rep_key.write(rep_key_header)
		for l in c:
			if l[0] == '>':
				if cluster:
					BIG_D[cluster] = gene_list
					rep_key_out = '%s\t%s\t%s\t%s\n' % (cluster, clust_rep, len(gene_list), ','.join(gene_list))
					rep_key.write(rep_key_out)

				cluster = '_'.join(l[1:].rstrip().split(' '))
				gene_list = []

			if l[0].isdigit():
				gene = l.split('>')[1].split('.')[0]
				gene_list.append(gene)
				isolate = '_'.join(gene.split('_')[:-2]) # for isolates
#				isolate = '_'.join(gene.split('_')[:-1]) # for closed references				
				binary_iD[isolate] = 0
				og_iD[isolate] = '-'
				rep_test = l.rstrip().split('... ')[1]
				if rep_test == '*':
					clust_rep = gene				
	
	biD_sorted = OrderedDict(sorted(binary_iD.items()))
	ogiD_sorted = OrderedDict(sorted(og_iD.items()))

	print('Finished Initial Parsing. Building DataFrames...')

	binary_out = clstr + '.binary.tsv'
	og_out = clstr + '.og.tsv'

	with open(binary_out, 'w') as bo, open(og_out, 'w') as ogo:

		b_colnames = '\t'.join(list(biD_sorted.keys()))
		bo.write(b_colnames + '\n')

		og_colnames = '\t'.join(list(ogiD_sorted.keys()))
		ogo.write(og_colnames + '\n')

		for clust, glist in BIG_D.items():
			binary_D[clust] = OrderedDict(biD_sorted)
			og_D[clust] = OrderedDict(ogiD_sorted)

			for g in glist:
				isolate = '_'.join(g.split('_')[:-2]) # for isolates
#				isolate = '_'.join(g.split('_')[:-1]) # for closed references
				binary_D[clust][isolate] = 1
				if og_D[clust][isolate] == '-':
					og_D[clust][isolate] = g
				else:
					og_D[clust][isolate] = og_D[clust][isolate] + ',' + g 

			blist = '\t'.join(map(str, list(binary_D[clust].values())))
			bo.write(blist + '\n')

			glist = '\t'.join(list(og_D[clust].values()))
			ogo.write(glist + '\n')

	return og_out, binary_out


def main():
	clstr_File = sys.argv[1]
	ogs,binary = resolve_clusters(clstr_File)

	print('Finished Building DataFrames. Generating Summary data...')

	ogs_summarize(ogs, 0)

	print('Finished Summaries. Building Core-Pan Cluster Map...')

	core_pan_clustermap(binary)

	

if __name__ == "__main__":
	main()
