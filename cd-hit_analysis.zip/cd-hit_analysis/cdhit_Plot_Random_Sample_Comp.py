#!~/.conda/envs/rothon/bin/python

## USAGE :: python scriptname.py variable...
## Script Description

import sys, matplotlib
matplotlib.use('PDF')
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

def Plot_Method_Comparison(df1, df2, df3):

	sns.set(style="white")
	plt1 = sys.argv[1].split('.')[0] + '_Plots.pdf'
	f, ((ax1, ax2, ax3), (ax4, ax5, ax6), (ax7, ax8, ax9), (ax10, ax11, ax12), (ax13, ax14, ax15)) = plt.subplots(5, 3, figsize=(22, 10), sharex=False, sharey=False)
	f.suptitle('Bar Plots Showing Comparisons Between Clustering Parameters', y=0.95, fontsize=24)
	ax1.set_title('Default Clustering Parameters', color='#006837')
	ax2.set_title('50% Length Difference / 90% Short Sequence Match', color='#045a8d')
	ax3.set_title('90% Length Difference / 90% Long Sequence Match', color='#810f7c')
	ax1.get_shared_y_axes().join(ax1, ax2, ax3)
	ax4.get_shared_y_axes().join(ax4, ax5, ax6)
	ax7.get_shared_y_axes().join(ax7, ax8, ax9)
	ax10.get_shared_y_axes().join(ax10, ax11, ax12)
	ax13.get_shared_y_axes().join(ax13, ax14, ax15)


	df1.Total_Clusters.plot.bar(color='#addd8e', width=0.8, ax=ax1)
	ax1.set_ylabel('Total_Clusters')
	ax1.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax1.minorticks_on()
	ax1.set_xticks([])
	ax1.set_xlabel('')

	df1.Core_Clusters.plot.bar(color='#78c679', width=0.8, ax=ax4)
	ax4.set_ylabel('Core_Clusters')
	ax4.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax4.minorticks_on()
	ax4.set_xticks([])
	ax4.set_xlabel('')

	df1.Unique_Clusters.plot.bar(color='#41ab5d', width=0.8, ax=ax7)
	ax7.set_ylabel('Unique_Clusters')
	ax7.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax7.minorticks_on()
	ax7.set_xticks([])
	ax7.set_xlabel('')

	df1.Avg_Clust_Size.plot.bar(color='#238443', width=0.8, ax=ax10)
	ax10.set_ylabel('Avg_Clust_Size')
	ax10.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax10.minorticks_on()
	ax10.set_xticks([])
	ax10.set_xlabel('')

	df1.Max_Clust_Size.plot.bar(color='#006837', width=0.8, ax=ax13)
	ax13.set_ylabel('Max_Clust_Size')
	ax13.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax13.minorticks_on()
	

	df2.Total_Clusters.plot.bar(color='#a6bddb', width=0.8, ax=ax2)
	ax2.set_ylabel('Total_Clusters')
	ax2.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax2.minorticks_on()
	ax2.set_xticks([])
	ax2.set_xlabel('')

	df2.Core_Clusters.plot.bar(color='#74a9cf', width=0.8, ax=ax5)
	ax5.set_ylabel('Core_Clusters')
	ax5.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax5.minorticks_on()
	ax5.set_xticks([])
	ax5.set_xlabel('')

	df2.Unique_Clusters.plot.bar(color='#3690c0', width=0.8, ax=ax8)
	ax8.set_ylabel('Unique_Clusters')
	ax8.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax8.minorticks_on()
	ax8.set_xticks([])
	ax8.set_xlabel('')

	df2.Avg_Clust_Size.plot.bar(color='#0570b0', width=0.8, ax=ax11)
	ax11.set_ylabel('Avg_Clust_Size')
	ax11.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax11.minorticks_on()
	ax11.set_xticks([])
	ax11.set_xlabel('')

	df2.Max_Clust_Size.plot.bar(color='#045a8d', width=0.8, ax=ax14)
	ax14.set_ylabel('Max_Clust_Size')
	ax14.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax14.minorticks_on()


	df3.Total_Clusters.plot.bar(color='#9ebcda', width=0.8, ax=ax3)
	ax3.set_ylabel('Total_Clusters')
	ax3.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax3.minorticks_on()
	ax3.set_xticks([])
	ax3.set_xlabel('')

	df3.Core_Clusters.plot.bar(color='#8c96c6', width=0.8, ax=ax6)
	ax6.set_ylabel('Core_Clusters')
	ax6.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax6.minorticks_on()
	ax6.set_xticks([])
	ax6.set_xlabel('')

	df3.Unique_Clusters.plot.bar(color='#8c6bb1', width=0.8, ax=ax9)
	ax9.set_ylabel('Unique_Clusters')
	ax9.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax9.minorticks_on()
	ax9.set_xticks([])
	ax9.set_xlabel('')

	df3.Avg_Clust_Size.plot.bar(color='#88419d', width=0.8, ax=ax12)
	ax12.set_ylabel('Avg_Clust_Size')
	ax12.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax12.minorticks_on()
	ax12.set_xticks([])
	ax12.set_xlabel('')

	df3.Max_Clust_Size.plot.bar(color='#810f7c', width=0.8, ax=ax15)
	ax15.set_ylabel('Max_Clust_Size')
	ax15.yaxis.grid(which="both", color='#d9d9d9', linestyle='--', linewidth=1)
	ax15.minorticks_on()


	ax13.tick_params(axis='x', rotation=-15, labelsize=8)
	ax14.tick_params(axis='x', rotation=-15, labelsize=8)
	ax15.tick_params(axis='x', rotation=-15, labelsize=8)
	ax13.set_xticklabels(df1.Name, rotation=15, fontsize=8, ha='right')
	ax14.set_xticklabels(df2.Name, rotation=15, fontsize=8, ha='right')
	ax15.set_xticklabels(df3.Name, rotation=15, fontsize=8, ha='right')
	ax13.set_xlabel('')
	ax14.set_xlabel('')
	ax15.set_xlabel('')
	plt.savefig(plt1)
	plt.close()


def main():
	header = ['Name', 'Total_Clusters', 'Core_Clusters', 'Unique_Clusters', 
			  'Avg_Clust_Size', 'Max_Clust_Size']
	df = pd.read_csv(sys.argv[1], sep='\t', header=None, names=header)
#	df['P'] = df['Sample_Name'].str.split('_').str[1]
#	df['Type'] = df['Sample_Name'].str.split('_').str[2]
#	df['Name'] = df['Sample_Name'].str.split('_').str[:2].str.join('_')
#	df.sort_values(by=['Type', 'P'], inplace=True)
	df1 = pd.DataFrame(df.iloc[0:9]) # isolate gene prediction test
	df2 = pd.DataFrame(df.iloc[9:18]) # isolate gene prediction test
	df3 = pd.DataFrame(df.iloc[18:27])

	Plot_Method_Comparison(df1, df2, df3)

if __name__ == "__main__":
	main()
