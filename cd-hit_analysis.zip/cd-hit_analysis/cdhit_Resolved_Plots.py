#!/usr/local/pacerepov1/python/2.7/bin/python

## USAGE :: python scriptname.py file.fasta prefix
## Reads fasta file and replaces sequence names with prefix_# counting from 1 to the end.
## Writes file.ref matching original names to new names.

## module load anaconda2/latest

import sys, matplotlib
matplotlib.use('PDF')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import seaborn as sns
sns.set(color_codes=True)
#sns.set()

sys.setrecursionlimit(50000)


def core_pan_clustermap(binary, sample_name):

	df = pd.read_csv(binary, sep='\t')
	core = df[df.sum(axis=1) == df.shape[1]].shape[0]
	unique = df[df.sum(axis=1) == 1].shape[0]
	variable = df[(df.sum(axis=1) > 1) & (df.sum(axis=1) < df.shape[1])].shape[0]
	data_line = '%s:: Genomes: %i | Core OGs: %i | Unique OGs: %i | Variable OGs: %i' % \
			(sample_name, len(df.columns), core, unique, variable)

	df_filtered = df[(df.sum(axis=1) > 1)]
	sorted_df = df_filtered.reindex(df.sum().sort_values(ascending = False).index, axis=1)
	df_sort = sorted_df.sort_values(sorted_df.columns[0], ascending = False)
	df_fin = df_sort.reset_index(drop=True)

#	mxf = ['#f7f7f7', '#980043'] #pink
	mxf = ['#ffffcc', '#006837'] #green
	pal = sns.color_palette(mxf)
#	g = sns.clustermap(df_fin, figsize=(50,20), metric="jaccard", method="weighted", cmap=pal, vmin=0, vmax=1, cbar_kws={"ticks":[0,1]})
#	g = sns.clustermap(df_fin, figsize=(50,20), method="single", cmap=pal, vmin=0, vmax=1, cbar_kws={"ticks":[0,1]}) # Nearest Point
#	g = sns.clustermap(df_fin, figsize=(50,20), method="centroid", cmap=pal, vmin=0, vmax=1, cbar_kws={"ticks":[0,1]}) # UPGMC
#	g = sns.clustermap(df_fin, figsize=(50,20), method="average", cmap=pal, vmin=0, vmax=1, cbar_kws={"ticks":[0,1]}) # UPGMA
#	g = sns.clustermap(df_fin, figsize=(50,20), metric="jaccard", cmap=pal, vmin=0, vmax=1, cbar_kws={"ticks":[0,1]})
	g = sns.clustermap(df_fin, figsize=(50,20), metric="euclidean", method="ward", cmap=pal, vmin=0, vmax=1, cbar_kws={"ticks":[0,1]})
#	g = sns.clustermap(df_fin, figsize=(50,20), metric="hamming", cmap=pal, vmin=0, vmax=1, cbar_kws={"ticks":[0,1]})
#	g = sns.clustermap(df_fin, figsize=(50,20), metric="correlation", cmap=pal, vmin=0, vmax=1, cbar_kws={"ticks":[0,1]}) # Throws ValueError
#	g = sns.clustermap(df_fin, figsize=(50,20), metric="braycurtis", cmap=pal, vmin=0, vmax=1, cbar_kws={"ticks":[0,1]})
	plt.setp(g.ax_heatmap.get_yticklabels(), rotation=0)  # For y axis
	plt.setp(g.ax_heatmap.get_xticklabels(), rotation=90) # For x axis
	plt.text(0.5, 1.12,data_line,fontsize=40,color='#980043',horizontalalignment='center',verticalalignment='center',transform = g.ax_heatmap.transAxes)
	plt.subplots_adjust(bottom=0.25)
	plt.savefig(sys.argv[1].split('.')[0] + '_Pan_Core_Clustermap.pdf')
	plt.close()

def main():
	binary = sys.argv[1]
	sample_name = sys.argv[2]
	core_pan_clustermap(binary, sample_name)

if __name__ == "__main__":
	main()

