#!~/.conda/envs/rothon/bin/python

## USAGE :: python scriptname.py cdhit_file.clstr
## Parses cdhit clusters into core, variable, and unique groups
## for core-pan genome analysis.
## builds rare-faction curve, unique genes per isolate barplot, and core-pan clustermap.

import sys, json
import pandas as pd
from collections import defaultdict

def pop_d2(d2, cluster, Isolates, RepSeq, RepSeqLen, IsoCount, Gene_Lens, pIdents):
#	print('Finished', cluster)
	d2['Cluster'].append(cluster)
	d2['Cluster_Size'].append(len(Isolates))
	d2['Representative_Sequence'].append(RepSeq)
	d2['RepSeq_Length'].append(RepSeqLen)
	d2['Isolates_in_Cluster'].append(len(IsoCount))
	d2['Isolate_Repeats'].append(len([x for x in IsoCount.values() if x > 1]))
	d2['Max_Gene_Len'].append(max(Gene_Lens))
	d2['Avg_Gene_Len'].append(sum(Gene_Lens)/len(Gene_Lens))
	d2['Min_Gene_Len'].append(min(Gene_Lens))
	d2['Max_pIdent'].append(max(pIdents))
	d2['Avg_pIdent'].append(sum(pIdents)/len(pIdents))
	d2['Min_pIdent'].append(min(pIdents))
	return d2

def parse_clusters(clstr):
	
	d1 = {'Cluster': [], 'Isolate': [], 'Gene_Length': [], 'Gene_Name': [], 'Percent_Identity': []}
	d2 = {'Cluster': [], 'Cluster_Size': [], 'Representative_Sequence': [], 'RepSeq_Length': [], 
		'Isolates_in_Cluster': [], 'Isolate_Repeats': [], 'Max_Gene_Len': [], 'Avg_Gene_Len': [], 
		'Min_Gene_Len': [], 'Max_pIdent': [], 'Avg_pIdent': [], 'Min_pIdent': []}
	d3 = defaultdict(list)

	cluster, Gene_Lens, pIdents, Isolates, IsoCount = None, [], [], [], defaultdict(int)

	with open(clstr, 'r') as c:
		for l in c:
			if l[0] == '>':
				if cluster:
					d2 = pop_d2(d2, cluster, Isolates, RepSeq, RepSeqLen, IsoCount, Gene_Lens, pIdents)
					cluster, Gene_Lens, pIdents, Isolates, IsoCount = None, [], [], [], defaultdict(int)
				cluster = l[1:8] + '_' + l[9:].rstrip()
				
			elif l[0].isdigit():
				X = l.rstrip().split(' ')
				isolate = X[1].split('_')[1] # for isolates
#				isolate = X[1].split('_')[2] # for Closed References 
				geneLen = int(X[0].split('\t')[1][:-3])
				geneName = X[1][1:-3]
				
				if X[2] == '*':
					RepSeq = geneName
					RepSeqLen = geneLen
					pident = 100.00
				elif X[2] == 'at':
					pident = float(X[3].split('/')[2][:-1])
				else:
					print('########### pIdent Flip OUT #############')

				Gene_Lens.append(geneLen)
				pIdents.append(pident)
				Isolates.append(isolate)
				IsoCount[isolate] += 1

				d1['Cluster'].append(cluster)
				d1['Isolate'].append(isolate)
				d1['Gene_Length'].append(geneLen)
				d1['Gene_Name'].append(geneName)
				d1['Percent_Identity'].append(pident)

				d3[isolate].append(cluster)

			else:
				print('################# FREAK OUT ######################')

	d2 = pop_d2(d2, cluster, Isolates, RepSeq, RepSeqLen, IsoCount, Gene_Lens, pIdents)

	# Save the Parsed Cluster data
	df1, df2 = pd.DataFrame(d1), pd.DataFrame(d2)
	prefix = '.'.join(clstr.split('.')[:3])
	n1, n2, n3 = prefix + '.df1.tsv', prefix + '.df2.tsv', prefix + '.df3.tsv'
	df1.to_csv(n1, sep='\t'), df2.to_csv(n2, sep='\t')
	with open(n3, 'w') as o: o.write(json.dumps(d3))

	return df1, df2, d3


def main():
	clstr_File = sys.argv[1]

	# Run the main function to Parse the CD-HIT CLuster file
	# Into usable tables
	print('Parsing Clusters File ...')
	df1, df2, d3 = cpc.parse_clusters(clstr_File)
	print('Finished Reselving Clusters. Writing DataFrames ...')

if __name__ == "__main__":
	main()
