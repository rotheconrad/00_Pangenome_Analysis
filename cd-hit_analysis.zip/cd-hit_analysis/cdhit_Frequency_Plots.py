#!~/.conda/envs/rothon/bin/python

## USAGE :: python scriptname.py variable...
## Script Description

import sys, matplotlib
matplotlib.use('PDF')
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

def Distribution_by_cluster(df, sample_name):
	df['Max-Min'] = df['Max_Gene_Len'] - df['Min_Gene_Len']
	cmap = ['#984ea3', '#ff7f00', '#a65628', '#f781bf']
	sns.set(style="whitegrid")

	plt1 = sys.argv[1].split('.')[0] + '_Clstr_Gene_Len.pdf'
	f, (ax1, ax2, ax3, ax4) = plt.subplots(4, 1, figsize=(7, 10), sharex=False, sharey=False)
	ax1.set_title(sample_name + ' Gene Lengths by Cluster')
	ax = sns.violinplot(df[['Max_Gene_Len']], color=cmap[0], ax=ax1)
	ax1.set_ylabel('Max_Gene_Len')
	ax = sns.violinplot(df[['Avg_Gene_Len']], color=cmap[1], ax=ax2)
	ax2.set_ylabel('Avg_Gene_Len')
	ax = sns.violinplot(df[['Min_Gene_Len']], color=cmap[2], ax=ax3)
	ax3.set_ylabel('Min_Gene_Len')
	ax = sns.violinplot(df[['Max-Min']], color=cmap[3], ax=ax4)
	ax4.set_ylabel('Max-Min')
	plt.savefig(plt1)
	plt.close()

	plt2 = sys.argv[1].split('.')[0] + '_Clstr_pIdent.pdf'
	ax = sns.violinplot(data=df[['Avg_pIdent', 'Min_pIdent']], palette=cmap)
	plt.title(sample_name + ' Percent Identity by Cluster')
	plt.savefig(plt2)
	plt.close()


	plt3 = sys.argv[1].split('.')[0] + '_Clstr_Gene_Count.pdf'
	f, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(7, 10), sharex=False, sharey=False)
	ax1.set_title(sample_name + ' Size Distribution')
	sns.violinplot(df[['Cluster_Size']], color=cmap[0], ax=ax1)
	ax1.set_ylabel('Cluster_Size')
	sns.violinplot(df[['Isolates_in_Cluster']], color=cmap[1], ax=ax2)
	ax2.set_ylabel('Isolates_in_Cluster')
	sns.violinplot(df[['Isolate_Repeats']], color=cmap[2], ax=ax3)
	ax3.set_ylabel('Isolate_Repeats')
	plt.savefig(plt3)
	plt.close()

	sns.set(style="white")
	fig = plt.figure(figsize=(12,6))
	plt4 = sys.argv[1].split('.')[0] + '_Unique_Genes_per_Isolate.pdf'
	df['Isolates'] = df.Representative_Sequence.str.split('_').str[1] # for isolates
#	df['Isolates'] = df.Representative_Sequence.str.split('_').str[2] # for closed genomes
	Unique_Genes = df[df['Isolates_in_Cluster'] == 1].groupby('Isolates').count().Cluster.sort_values(ascending=False)
	Unique_Genes.plot.bar(color='#636363', width=0.8)
	plt.title(sample_name + ' Unique Genes Per Isolate')
	ax = plt.gca()
	ax.yaxis.grid(which="major", color='#d9d9d9', linestyle='--', linewidth=1)
	ax.tick_params(axis='x', rotation=90, labelsize=6)
	plt.savefig(plt4)
	plt.close()

	fig = plt.figure(figsize=(12,6))
	plt5 = sys.argv[1].split('.')[0] + '_Isolates_in_Cluster.pdf'
	df.groupby('Isolates_in_Cluster').count().Cluster.plot.bar(color='#2171b5', width=0.8)
	plt.title(sample_name + ' Isolates in Cluster')
	ax = plt.gca()
	ax.yaxis.grid(which="major", color='#d9d9d9', linestyle='--', linewidth=1)
	ax.tick_params(axis='x', rotation=90, labelsize=6)
	plt.savefig(plt5)
	plt.close()

	fig = plt.figure(figsize=(12,6))
	plt6 = sys.argv[1].split('.')[0] + '_Number_Isolate_Repeats.pdf'
	df.groupby('Isolate_Repeats').count().Cluster.plot.bar(color='#88419d', width=0.8)
	plt.title(sample_name + ' Number of Repeated Isolates Per Cluster')
	ax = plt.gca()
	ax.yaxis.grid(which="major", color='#d9d9d9', linestyle='--', linewidth=1)
	ax.tick_params(axis='x', rotation=90, labelsize=6)
	plt.savefig(plt6)
	plt.close()

def main():
	df = pd.read_csv(sys.argv[1], sep='\t', index_col=0)
	sample_name = sys.argv[2]
	Distribution_by_cluster(df, sample_name)

if __name__ == "__main__":
	main()

