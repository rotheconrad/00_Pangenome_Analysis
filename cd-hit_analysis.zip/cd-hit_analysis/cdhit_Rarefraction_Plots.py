#!~/.conda/envs/rothon/bin/python

## USAGE :: python scriptname.py variable...
## Script Description

import sys, json, matplotlib
matplotlib.use('PDF')
from random import shuffle
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

def Plot_Rarefaction(data, sample_name):
	lst = list(data.items())
	rfctn = {'Sample': [], 'Clusters': [], 'Legend': []}
	new_per = {'Sample': [], 'New_Clusters': []}

	for i in range(100):
		shuffle(lst)
		count = 1
		total = set()
		for sample, clusters in lst:
			current = set(clusters)
			if count == 1:
				shared = current
				total = current
				ttl = current
			else:
				ttl = total.union(current)
				shared = shared.intersection(current)
			
			pan = len(ttl)
			core = len(shared)
			new = len(ttl) - len(total)
			rfctn['Sample'].append(count)
			rfctn['Clusters'].append(pan)
			rfctn['Legend'].append('Pan')
			rfctn['Sample'].append(count)
			rfctn['Clusters'].append(core)
			rfctn['Legend'].append('Core')
			new_per['Sample'].append(count)
			new_per['New_Clusters'].append(new)
			total = ttl
			count += 1

	df1 = pd.DataFrame(rfctn)
	df2 = pd.DataFrame(new_per)

	sns.set_style("whitegrid")
	fig = plt.figure(figsize=(20,10))
	ax = sns.lineplot(x='Sample', y='Clusters', hue='Legend', data=df1, palette=['#1f78b4','#ff7f00'])
	stext = 'Total Clusters: %i  |  Core Clusters: %i' % (len(total), core)
	plt.text(0.01, 0.01, stext, fontsize=14, color='#737373', horizontalalignment='left', transform=ax.transAxes)
	plt.legend(loc='upper left')
	plt.title(sample_name + ' Pan-Core Rarefaction', fontsize=38, y=1.02)
	plt.xlabel('Number of Genomes', fontsize=30, y=-0.02)
	plt.ylabel('Number of Gene Clusters', fontsize=30, x=-0.02)
	plt.xticks(range(0, len(data)+8, 7)) # for isolates or larger groups
#	plt.xticks(range(0, len(data)+2, 1)) # for closed genomes or smaller groups
	plt.yticks(range(core-100, pan+100, 500))
	
	a = plt.axes([0.45, 0.25, 0.4, 0.3], facecolor='#ffffe5')
	sns.barplot('Sample', 'New_Clusters', data=df2, color='#fe9929')
	plt.title('New Clusters Per Genome', fontsize=28, color='#fe9929', y=0.85)
	plt.xlabel('')
	plt.ylabel('')
	plt.xticks([])

	plt.savefig(sys.argv[1].split('.')[0] + '_Rarefaction_of_Gene_Clusters.pdf')
	plt.close()

def Plot_Genes_per_Isolate(data, sample_name):
	genes_per = {'Sample': [], 'Genes': [], 'Clusters': [], 'Difference': []}

	for sample, clusters in data.items():
		total_genes = len(clusters) # This will change to sum(clusters.values())
		total_clusts = len(set(clusters)) # This will change to len(clusters)
		difference = total_genes - total_clusts
		genes_per['Sample'].append(sample)
		genes_per['Genes'].append(total_genes)
		genes_per['Clusters'].append(total_clusts)
		genes_per['Difference'].append(difference)

	df = pd.DataFrame(genes_per)

	sns.set_style("whitegrid")
	fig, ax = plt.subplots(figsize=(20,10))
	df.plot.line(rot=0, ax=ax)
	plt.title(sample_name + ' Per Isolate Totals', fontsize=38, y=1.02)
	plt.xlabel('Genomes', fontsize=30, y=-0.02)
	plt.ylabel('Number of Genes or Gene Clusters', fontsize=30, x=-0.02)
	plt.savefig(sys.argv[1].split('.')[0] + '_Total_Genes_vs_Clusters.pdf')
	plt.close()

def main():
	with open(sys.argv[1], 'r') as data:
		d3 = json.load(data)
		Plot_Rarefaction(d3)
		Plot_Genes_per_Isolate(d3)

if __name__ == "__main__":
	main()
