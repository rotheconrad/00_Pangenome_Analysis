#!/usr/local/pacerepov1/python/2.7/bin/python

## USAGE :: python scriptname.py file.fasta prefix
## Reads fasta file and replaces sequence names with prefix_# counting from 1 to the end.
## Writes file.ref matching original names to new names.

import sys

def ogs_summarize(ogsFile, switch):

#	find and replace ref_name = '_'.join(g.split('_')[:-2]) # for isolates
#	find and replace ref_name = '_'.join(g.split('_')[:-1]) # for closed references

	gDict = {'core100': {}, 'core90': {}, 'core80': {}, 'vari70': {}, 'vari60': {}, 'vari50': {}, \
		'vari40': {}, 'vari30': {}, 'vari20': {}, 'vari10': {}, 'vari01': {}, 'uniq00': {}}

	geneCounts = {'core100': 0, 'core90': 0, 'core80': 0, 'vari70': 0, 'vari60': 0, 'vari50': 0, \
		'vari40': 0, 'vari30': 0, 'vari20': 0, 'vari10': 0, 'vari01': 0, 'uniq00': 0}

	ogCounts = {'core100': 0, 'core90': 0, 'core80': 0, 'vari70': 0, 'vari60': 0, 'vari50': 0, \
		'vari40': 0, 'vari30': 0, 'vari20': 0, 'vari10': 0, 'vari01': 0, 'uniq00': 0}

	total_genes = 0
	total_ogs = 0
	total_genomes = 0

	with open(ogsFile, 'r') as ogs:
		smpls = ogs.readline().rstrip().split('\t')
		total_genomes += len(smpls)
		for s in smpls:
			for d in gDict.values():
				d[s] = []

		for og in ogs:
			X = og.rstrip().split('\t')
			x = X.count('-')
			l = [y.split(',') for y in X if y != '-']
			genes = [item for sublist in l for item in sublist]
			gene_count = len(genes)
			total_genes += gene_count
			total_ogs += 1
			prcnt = (total_genomes - x) / total_genomes

			if prcnt == 1:
				ogCounts['core100'] += 1
				geneCounts['core100'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['core100'][ref_name].append(g)

			elif prcnt >= 0.9:
				ogCounts['core90'] += 1
				geneCounts['core90'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['core90'][ref_name].append(g)

			elif prcnt >= 0.8:
				ogCounts['core80'] += 1
				geneCounts['core80'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['core80'][ref_name].append(g)

			elif prcnt >= 0.7:
				ogCounts['vari70'] += 1
				geneCounts['vari70'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['vari70'][ref_name].append(g)

			elif prcnt >= 0.6:
				ogCounts['vari60'] += 1
				geneCounts['vari60'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['vari60'][ref_name].append(g)

			elif prcnt >= 0.5:
				ogCounts['vari50'] += 1
				geneCounts['vari50'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['vari50'][ref_name].append(g)

			elif prcnt >= 0.4:
				ogCounts['vari40'] += 1
				geneCounts['vari40'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['vari40'][ref_name].append(g)

			elif prcnt >= 0.3:
				ogCounts['vari30'] += 1
				geneCounts['vari30'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['vari30'][ref_name].append(g)

			elif prcnt >= 0.2:
				ogCounts['vari20'] += 1
				geneCounts['vari20'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['vari20'][ref_name].append(g)

			elif prcnt >= 0.1:
				ogCounts['vari10'] += 1
				geneCounts['vari10'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['vari10'][ref_name].append(g)

			elif prcnt > (1 / total_genomes):
				ogCounts['vari01'] += 1
				geneCounts['vari01'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['vari01'][ref_name].append(g)

			elif prcnt == (1 / total_genomes):
				ogCounts['uniq00'] += 1
				geneCounts['uniq00'] += gene_count
				for g in genes:
					ref_name = '_'.join(g.split('_')[:-2])
					gDict['uniq00'][ref_name].append(g)

			else:
				print(X)

	print('Total Genomes: %i\tTotal OrthoGroups: %i\tTotal Genes: %i' % (total_genomes, total_ogs, total_genes))
	print('Group\tOrthoGroups\tOG_Prcnt\tGenes\tGenes_Prcnt')

	stats_File = '%s.stats.tsv' % (ogsFile)
	with open(stats_File, 'w') as stats_out:
		for k,v in gDict.items():
			OG_Prcnt = "{:.2f}".format(ogCounts[k]/total_ogs*100)
			Genes_Prcnt = "{:.2f}".format(geneCounts[k]/total_genes*100)
			line_out = '%s\t%i\t%s\t%i\t%s' % (k, ogCounts[k], OG_Prcnt, geneCounts[k], Genes_Prcnt)
			print(line_out)
			stats_out.write(line_out + '\n')

			if switch == 1:
				outFile = '%s_%s_genes.txt' % (ogsFile.split('.')[0], k)
				with open(outFile, 'w') as o:
					for isolate, genes in v.items():
						o.write(isolate + ':\t' + '\t'.join(genes) + '\n')

def main():
	ogsFile = sys.argv[1]
	switch = int(sys.argv[2])
	ogs_summarize(ogsFile, switch)
	
if __name__ == "__main__":
	main()

