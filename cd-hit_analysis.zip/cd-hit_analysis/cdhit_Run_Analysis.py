#!~/.conda/envs/rothon/bin/python

## USAGE :: python scriptname.py cdhit_file.clstr
## Parses cdhit clusters into core, variable, and unique groups
## for core-pan genome analysis.
## builds rare-faction curve, unique genes per isolate barplot, and core-pan clustermap.

import sys
import pandas as pd
from cdhit_Parse_Clusters import parse_clusters
from cdhit_Resolve_Clusters import resolve_clusters
from cdhit_summarize import ogs_summarize
from cdhit_Frequency_Plots import Distribution_by_cluster
import cdhit_Rarefraction_Plots as crp
import cdhit_Resolved_Plots as crc

def main():

	clstr_File = sys.argv[1]

	# Define Test Parameters
	if len(sys.argv) == 4:
		program = sys.argv[3]
		cluster_threshold = sys.argv[2] 
	elif len(sys.argv) == 3:
		program = sys.argv[1].split('_')[4]
		cluster_threshold = sys.argv[2]
	else:
		program = sys.argv[1].split('_')[4]
		cluster_threshold = sys.argv[1].split('.')[0].split('_')[5]
#	fasta_ext = sys.argv[1].split('.')[2] # origial
	fasta_ext = sys.argv[1].split('.')[-2] # for strict / loose extention
	extDict = {'faa': 'Amino-Acid', 'fnn': 'Nucleotide'}
	seq_type = extDict[fasta_ext]
	sample_name = '%s %s%% %s Identity Clusters' % (program, cluster_threshold, seq_type)
	sname = '%s_%s%%_%s' % (program, cluster_threshold, seq_type)

	# Run the main function to Parse the CD-HIT CLuster file
	# Into usable tables
	print('Parsing Clusters File ...')
	df1, df2, d3 = parse_clusters(clstr_File)
	print('Finished Resolving Clusters. Building Plots ...')

	# Build some plots
	Distribution_by_cluster(df2, sample_name)
	crp.Plot_Rarefaction(d3, sample_name)
	crp.Plot_Genes_per_Isolate(d3, sample_name)

	print('Parsing and summary plots complete. Resolving Clusters ...')
	# Run the second main function to Resolve CD-HIT Clusters
	ogs,binary = resolve_clusters(clstr_File)
	print('Finished Building DataFrames. Generating Summary data...')
	ogs_summarize(ogs, 0)
	print('Finished Summaries. Building Core-Pan Cluster Map...')
	crc.core_pan_clustermap(binary, sample_name)
	print('Finishing Parsing and plotting. Script finished successfully.')

	with open('Clustering_Method_Comparisons.tsv', 'a') as o:
		tClust = len(df2)
		tIsolates = len(d3)
		cClust = len(df2[df2['Isolates_in_Cluster'] == tIsolates])
		uClust = len(df2[df2['Isolates_in_Cluster'] == 1])
		aClust = df2['Cluster_Size'].mean()
		mClust = df2['Cluster_Size'].max()
		line_out = '%s\t%s\t%s\t%s\t%s\t%s\n' % (sname, tClust, cClust, uClust, aClust, mClust)
		o.write(line_out)

if __name__ == "__main__":
	main()
